#1 = collude
#0 = defect

def play(opponentMove):
  if opponentMove == 'start':
    return 1
  return 1


def name():
  return 'allwaysCollude'
