#1 = collude
#0 = defect

def play(opponentMove):
  if opponentMove == 'start':
    return 0
  return 0

def name():
  return 'allwaysDefect'

