Prisoner's dilemma 

This project compares various strategies in the prisoner's dilemma.

Written using Python3.7

